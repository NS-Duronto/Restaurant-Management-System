<?php

namespace App\Http\Controllers\Admin;

use Exception;
use App\Services\OrderService;
use App\Services\CustomerService;
use App\Http\Requests\CustomerRequest;
use App\Http\Requests\PosOrderRequest;
use App\Http\Resources\CustomerResource;
use App\Http\Resources\OrderDetailsResource;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\Middleware;


class PosController extends AdminController
{
    private OrderService $orderService;
    private CustomerService $customerService;

    public function __construct(OrderService $order, CustomerService $customerService)
    {
        parent::__construct();
        $this->orderService = $order;
        $this->customerService = $customerService;
    }

    public static function middleware(): array
    {
        return [
            new Middleware('permission:pos', only: ['store', 'nextToken']),
        ];
    }

    public function nextToken(Request $request): \Illuminate\Http\JsonResponse
    {
        try {
            $branchId = $request->branch_id ? (int) $request->branch_id : null;
            $token = $this->orderService->generateNextToken($branchId);

            return response()->json([
                'status' => true,
                'data' => [
                    'token' => $token,
                ],
            ]);
        } catch (Exception $exception) {
            return response()->json([
                'status' => false,
                'message' => $exception->getMessage(),
            ], 422);
        }
    }

    public function store(PosOrderRequest $request): \Illuminate\Http\Response | OrderDetailsResource | \Illuminate\Contracts\Foundation\Application | \Illuminate\Contracts\Routing\ResponseFactory
    {
        try {
            return new OrderDetailsResource($this->orderService->posOrderStore($request));
        } catch (Exception $exception) {
            return response(['status' => false, 'message' => $exception->getMessage()], 422);
        }
    }

    public function storeCustomer(
        CustomerRequest $request
    ): \Illuminate\Http\Response|CustomerResource|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory {
        try {
            return new CustomerResource($this->customerService->store($request));
        } catch (Exception $exception) {
            return response(['status' => false, 'message' => $exception->getMessage()], 422);
        }
    }
}
